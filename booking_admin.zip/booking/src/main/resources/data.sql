insert into admin values (1,'abc','abc@gmail.com','abcpassword');
 