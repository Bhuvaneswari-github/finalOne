package com.flightapp.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.repository.FlightBookingRepository;

@Service
public class FlightBookingService {
	
	@Autowired
	FlightBookingRepository repo;
	
	public void storeName(UserDetails name) {
		 repo.save(name);
	}

}
