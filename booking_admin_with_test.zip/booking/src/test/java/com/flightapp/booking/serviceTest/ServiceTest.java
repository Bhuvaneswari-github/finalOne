package com.flightapp.booking.serviceTest;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.flightapp.booking.model.NewFlightDetails;
import com.flightapp.booking.repository.FlightBookingRepository;
import com.flightapp.booking.repository.FlightBookingRepositoryJpa;
import com.flightapp.booking.service.FlightBookingService;
import com.flightapp.booking.service.FlightServiceJpa;

@SpringBootTest
public class ServiceTest {
	@MockBean
	private FlightBookingRepositoryJpa repoTest;
	
	@Autowired
	private FlightServiceJpa serviceTest;
	
	@Test
	public void getDisplayFlightDetails() {
		NewFlightDetails nf= new NewFlightDetails();
		nf.setAirlineName("abc");
		List<NewFlightDetails>ndf= new LinkedList<>();
		ndf.add(nf);
		
				Mockito.when(repoTest.findAll()).thenReturn(ndf);
		List<NewFlightDetails> nd=serviceTest.findAllFlightDetails();
		Assertions.assertEquals(nd.get(0).getAirlineName(), "abc");
	}
	

}
