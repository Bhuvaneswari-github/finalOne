package com.flight.flightService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flight.flightService.dto.FlightSearchResults;
import com.flight.flightService.dto.FlightBookingTicketDetails;
import com.flight.flightService.dto.FlightException;
import com.flight.flightService.service.FlightService;

@RestController
@RequestMapping("/v1/flight")
public class FlightController {
	@Autowired
	FlightService service;
	
	/*
	 * @PostMapping("/save") public String details(@RequestBody Flight f) { return
	 * service.saveDetails(f); }
	 * 
	 * @GetMapping("/{id}") public Flight displayFlightDetails(@PathVariable("id")
	 * int fNum) { List<Flight> nf = new ArrayList<>(); Flight nfd1
	 * =service.findDetailsById(fNum);
	 * //System.out.println("Sample"+nfd1.getAirlineName()); return nfd1; }
	 */
	@GetMapping("/searchFlights/{flightname}/{departure}/{arrival}")
	public List<FlightSearchResults> emailId(@PathVariable("flightname") String flightname,
			@PathVariable("departure") String departure,
			@PathVariable("arrival") String arrival) {
		
		RestTemplate rt=new RestTemplate();
		ResponseEntity<List<FlightSearchResults>> ra=rt.exchange("http://localhost:8081/v1/api/displayFlightDetails", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<FlightSearchResults>>(){});
		
		ResponseEntity<List<FlightSearchResults>> s=service.displayBasedOnSearch(ra,flightname,departure,arrival);
		return s.getBody();
	}
	/*
	 * @PostMapping("/bookTickets") public String details(@RequestBody
	 * List<Passengers> pDetails,
	 * 
	 * @RequestParam(required = false, name = "email") int email,
	 * 
	 * @RequestParam(required = false, name = "noOfSeats") int seatCount) { return
	 * service.saveBookingDetails(pDetails,email,seatCount); }
	 */
	@PostMapping("/bookTickets")
	public String details(@RequestBody FlightBookingTicketDetails ftd) {
		return service.saveBookingDetails(ftd);
	}
	@GetMapping("/TicketsDetails")
	public List<FlightBookingTicketDetails> ticketdetails() {
		return service.sfind();
	}
	@GetMapping("/TicketsDetails/{pnr}")
	public FlightBookingTicketDetails ticketdetailsbypnr(@PathVariable int pnr) throws FlightException {
		return service.findbyDetailsId(pnr);
	}
	@GetMapping("/fetching/history/{email}")
	public List<FlightBookingTicketDetails> ticketdetailsbypemail(@PathVariable String email) {
		return service.findbyDetailsemail(email);
	}
}
