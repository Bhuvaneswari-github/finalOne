package com.flight.flightService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.flightService.model.Passengers;

public interface PassengersRepo extends JpaRepository<Passengers, Integer>{

}
