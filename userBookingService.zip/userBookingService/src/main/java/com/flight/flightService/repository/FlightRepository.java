package com.flight.flightService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.flight.flightService.dto.FlightBookingTicketDetails;
import com.flight.flightService.dto.FlightSearchResults;

@Repository
public interface FlightRepository extends JpaRepository<FlightBookingTicketDetails, Integer> {
	FlightSearchResults fsr = new FlightSearchResults();
	
	FlightBookingTicketDetails save(FlightBookingTicketDetails d);
	List<FlightBookingTicketDetails> findAll();

	@Query("from FlightBookingTicketDetails f where f.email = :email")
	List<FlightBookingTicketDetails> findByEmail(String email);
	

}
