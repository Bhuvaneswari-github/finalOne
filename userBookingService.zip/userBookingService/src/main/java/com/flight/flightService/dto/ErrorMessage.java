package com.flight.flightService.dto;

import java.time.LocalDateTime;

public class ErrorMessage {
	private String message;
	private int status;
	private LocalDateTime dateTime;
	public ErrorMessage() {
		super();
	}
	public ErrorMessage(String message, int status, LocalDateTime dateTime) {
		super();
		this.message = message;
		this.status = status;
		this.dateTime = dateTime;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	@Override
	public String toString() {
		return "ErrorMessage [message=" + message + ", status=" + status + ", dateTime=" + dateTime + ", getMessage()="
				+ getMessage() + ", getStatus()=" + getStatus() + ", getDateTime()=" + getDateTime() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
