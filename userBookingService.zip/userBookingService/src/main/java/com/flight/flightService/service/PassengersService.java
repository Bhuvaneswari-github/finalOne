package com.flight.flightService.service;

public class PassengersService {

}
