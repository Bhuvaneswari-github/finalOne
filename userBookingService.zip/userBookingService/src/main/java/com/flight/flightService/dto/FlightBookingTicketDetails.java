package com.flight.flightService.dto;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.flight.flightService.model.Passengers;

@Entity
public class FlightBookingTicketDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pnr;
	private String email;
	@OneToMany(targetEntity = Passengers.class,cascade = CascadeType.ALL)
	@JoinColumn(name= "up_fk",referencedColumnName = "pnr")
	private List<Passengers> passengers;
	private String noOfSeats;
	private String flightNumber;
	private String departute;
	private String arrival;
	private LocalDateTime departureDateTime;
	private LocalDateTime arrivalDteTime;
	private String meals;
	private Double price;
	public long getPnr() {
		return pnr;
	}
	public void setPnr(int pnr) {
		this.pnr = pnr;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Passengers> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<Passengers> passengers) {
		this.passengers = passengers;
	}
	public String getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(String noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getDepartute() {
		return departute;
	}
	public void setDepartute(String departute) {
		this.departute = departute;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}
	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
	public LocalDateTime getArrivalDteTime() {
		return arrivalDteTime;
	}
	public void setArrivalDteTime(LocalDateTime arrivalDteTime) {
		this.arrivalDteTime = arrivalDteTime;
	}
	public String getMeals() {
		return meals;
	}
	public void setMeals(String meals) {
		this.meals = meals;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public FlightBookingTicketDetails(int pnr, String email, List<Passengers> passengers, String noOfSeats,
			String flightNumber, String departute, String arrival, LocalDateTime departureDateTime,
			LocalDateTime arrivalDteTime, String meals, Double price) {
		super();
		this.pnr = pnr;
		this.email = email;
		this.passengers = passengers;
		this.noOfSeats = noOfSeats;
		this.flightNumber = flightNumber;
		this.departute = departute;
		this.arrival = arrival;
		this.departureDateTime = departureDateTime;
		this.arrivalDteTime = arrivalDteTime;
		this.meals = meals;
		this.price = price;
	}
	public FlightBookingTicketDetails() {
		super();
	}

	
	
	

}
