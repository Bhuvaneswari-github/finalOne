package com.flight.flightService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class userBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(userBookingServiceApplication.class, args);
	}

}
