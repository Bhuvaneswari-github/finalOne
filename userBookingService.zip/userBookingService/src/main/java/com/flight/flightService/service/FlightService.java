package com.flight.flightService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flight.flightService.dto.FlightBookingTicketDetails;
import com.flight.flightService.dto.FlightException;
import com.flight.flightService.dto.FlightSearchResults;
import com.flight.flightService.repository.FlightRepository;

@Service
public class FlightService {
	@Autowired
	FlightRepository repo;

/*
 * public String saveDetails(Flight f) { repo.save(f); return "Success"; }
 * public Flight findDetailsById(int fNum) { // TODO Auto-generated method stub
 * return repo.findById(fNum); }
 */
	public String saveBookingDetails(FlightBookingTicketDetails ftd) {
		repo.save(ftd);
		return "Tickets Booked";
	}

	public List<FlightBookingTicketDetails> sfind() {
		return repo.findAll();
	}

	@Cacheable(key="#id", value="flightCache")
	public FlightBookingTicketDetails findbyDetailsId(int pnr) throws FlightException {
		Optional<FlightBookingTicketDetails> fbookdetails= repo.findById(pnr);
		if(fbookdetails.isEmpty()) {
			throw new FlightException("Fight Details not found");
		}
		else {
			return fbookdetails.get();
		}
		
	}

	public List<FlightBookingTicketDetails> findbyDetailsemail(String email) {
		return repo.findByEmail(email);
	}


	public ResponseEntity<List<FlightSearchResults>> displayBasedOnSearch(ResponseEntity<List<FlightSearchResults>> ra, String flightname,
			String departure, String arrival) {
		
		if(ra.getBody().equals(flightname) || ra.getBody().equals(departure) ||ra.getBody().equals(arrival)) {
			ra.getBody();			
			return ra;
		}
		return ra;
	}
	

}
