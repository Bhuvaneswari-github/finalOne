package com.flight.flightService.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flight.flightService.dto.Admin;
import com.flight.flightService.model.Flight;
import com.flight.flightService.service.FlightService;

@RestController
@RequestMapping("/v1/flight")
public class FlightController {
	@Autowired
	FlightService service;
	
	@PostMapping("/save")
	public String details(@RequestBody Flight f) {
		return service.saveDetails(f);
	}
	@GetMapping("/{id}")
	public Flight displayFlightDetails(@PathVariable("id") int fNum) {
		List<Flight> nf  = new ArrayList<>();
		Flight nfd1 =service.findDetailsById(fNum);
		System.out.println("Sample");
		return nfd1;
	}
	@GetMapping("/email")
	public void emailId() {
		//List<Flight> nf  = new ArrayList<>();
		//Flight nfd1 =service.findDetailsById(fNum);
		//System.out.println("Sample"+nfd1.getAirlineName());
		RestTemplate rt=new RestTemplate();
	//	ParameterizedPreparedStatementSetter<List<Admin>> pa=new ParameterizedPreparedStatementSetter<List<Admin>>(){};
		ResponseEntity<List<Admin>> ra=rt.exchange("http://localhost:8081/v1/api/displayFlightDetails", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Admin>>(){});
System.out.println("sample"+ra.getBody().get(0).getAirlineName());
	}
}
