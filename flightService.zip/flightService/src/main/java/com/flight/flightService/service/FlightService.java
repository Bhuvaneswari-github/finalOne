package com.flight.flightService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.flightService.model.Flight;
import com.flight.flightService.repository.FlightRepository;

@Service
public class FlightService {
@Autowired
FlightRepository repo;
	public String saveDetails(Flight f) {
		repo.save(f);
		return "Success";
	}
	public Flight findDetailsById(int fNum) {
		// TODO Auto-generated method stub
		return repo.findById(fNum);
	}
	

}
