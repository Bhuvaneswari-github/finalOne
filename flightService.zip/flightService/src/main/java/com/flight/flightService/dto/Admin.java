package com.flight.flightService.dto;

import java.time.LocalDateTime;

public class Admin {
	private int id;
	private String airlineName;
	private String departute;
	private String arrival;
	private LocalDateTime departureDateTime;
	private LocalDateTime arrivalDteTime;
	private String meals;
	private Double price;
	private int maxSeats;
	private String status;
	

	public void NewFlightDetails(int id, String airlineName, String departute, String arrival,
			LocalDateTime departureDateTime, LocalDateTime arrivalDteTime, String meals, Double price, int maxSeats,
			String status) {
		
		this.id = id;
		this.airlineName = airlineName;
		this.departute = departute;
		this.arrival = arrival;
		this.departureDateTime = departureDateTime;
		this.arrivalDteTime = arrivalDteTime;
		this.meals = meals;
		this.price = price;
		this.maxSeats = maxSeats;
		this.status = status;
	}
	public void NewFlightDetails(String airlineName, String departute, String arrival,
			LocalDateTime departureDateTime, LocalDateTime arrivalDteTime, String meals, Double price, int maxSeats,
			String status) {
		
		
		this.airlineName = airlineName;
		this.departute = departute;
		this.arrival = arrival;
		this.departureDateTime = departureDateTime;
		this.arrivalDteTime = arrivalDteTime;
		this.meals = meals;
		this.price = price;
		this.maxSeats = maxSeats;
		this.status = status;
	}
	public void NewFlightDetails() {
		
	}
	public int getFlightNum() {
		return id;
	}
	public void setFlightNum(int id) {
		this.id = id;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	public String getDepartute() {
		return departute;
	}
	public void setDepartute(String departute) {
		this.departute = departute;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}
	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
	public LocalDateTime getArrivalDteTime() {
		return arrivalDteTime;
	}
	public void setArrivalDteTime(LocalDateTime arrivalDteTime) {
		this.arrivalDteTime = arrivalDteTime;
	}
	public String getMeals() {
		return meals;
	}
	public void setMeals(String meals) {
		this.meals = meals;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public int getMaxSeats() {
		return maxSeats;
	}
	public void setMaxSeats(int maxSeats) {
		this.maxSeats = maxSeats;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
}
